<?php

namespace App\Policies;

use App\User;
use App\Item;
use App\Mythesis;
use Illuminate\Auth\Access\HandlesAuthorization;

class MythesisPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can see the items.
     *
     * @param  \App\User  $user
     * @return boolean
     */
    public function viewAny(User $user)
    {
        return true;
    }

    /**
     * Determine whether the user can create items.
     *
     * @param  \App\User  $user
     * @return boolean
     */
    public function create(User $user)
    {
        return $user->isAdmin() || $user->isManager() ||  $user->isCreator();
    }

    /**
     * Determine whether the user can update the item.
     *
     * @param  \App\User  $user
     * @param  \App\Item  $item
     * @return boolean
     */
    public function update(User $user, Item $item)
    {
        return $user->isAdmin() || $user->isManager() || $user->isCreator();
    }
	
	/**
     * Determine whether the user can update the item.
     *
     * @param  \App\User  $user
     * @param  \App\Item  $item
     * @return boolean
     */
    public function detail(User $user, Item $item)
    {
        return $user->isMember();
    }
	
	/**
     * Determine whether the user can update the item.
     *
     * @param  \App\User  $user
     * @param  \App\Item  $item
     * @return boolean
     */
    public function allocation(User $user, Item $item)
    {
        return $user->isMember();
    }

    /**
     * Determine whether the user can delete the item.
     *
     * @param  \App\User  $user
     * @param  \App\Item  $item
     * @return boolean
     */
    public function delete(User $user, Item $item)
    {
        return $user->isAdmin() || $user->isManager();
    }
}